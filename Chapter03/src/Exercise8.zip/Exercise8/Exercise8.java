/*Group 17 Eong Koungmeng*/

package Exercise8;

import java.util.Scanner;

public class Exercise8
{
	static Scanner input;
	
	public static void main(String[] args)
	{
		input = new Scanner(System.in);
		
		GameLauncher launcher = new GameLauncher();
		launcher.run();
	}
}
