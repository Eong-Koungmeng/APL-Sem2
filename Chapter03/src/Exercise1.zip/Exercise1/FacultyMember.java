package Exercise1;

class FacultyMember extends Employee
{
	int officeHours;
	String position;
	
	public String toString()
	{	
		return "Class name = FacultyMember" + ", Person's name = " + name;
	}
}
