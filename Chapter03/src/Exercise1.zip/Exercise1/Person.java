package Exercise1;

class Person
{
	String name;
	String address;
	String phoneNumber;
	String emailAddress;
	
	public String toString()
	{	
		return "Class name = Person" + ", Person's name = " + name;
	}
}