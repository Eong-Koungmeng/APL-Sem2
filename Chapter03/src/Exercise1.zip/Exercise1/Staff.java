package Exercise1;

class Staff extends Employee
{
	String title;
	
	public String toString()
	{	
		return "Class name = Staff" + ", Person's name = " + name;
	}
}
