package Exercise3;

class Dog extends Animal
{
	void makeSound()
	{
		System.out.println("Woof Woof");
	}
}
