package Exercise3;

class Animal
{

	void makeSound()
	{
		System.out.println("Animal making sound");
	}
}
