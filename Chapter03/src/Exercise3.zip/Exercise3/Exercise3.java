/*Group 17 Eong Koungmeng*/
package Exercise3;

public class Exercise3
{
	public static void main(String[] args)
	{
		Zoo zoo = new Zoo();
		zoo.speak();
	}
}
