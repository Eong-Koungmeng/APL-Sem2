
public class Teacher
{
	String TeacherID;
	String TeacherName;
	String Gender;
	String DOB;
	String PhoneNo;
	String Address;
	String AccountID;
}
