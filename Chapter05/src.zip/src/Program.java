import java.io.IOException;

interface Program
{
	void Update() throws IOException;
}
