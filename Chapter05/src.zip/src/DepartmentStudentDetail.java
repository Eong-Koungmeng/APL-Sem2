
public class DepartmentStudentDetail
{
	String DeptID;
	String StudentID;
}
