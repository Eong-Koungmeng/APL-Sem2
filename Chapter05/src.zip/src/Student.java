
public class Student
{
	String StudentID;
	String StudentName;
	String Gender;
	String DOB;
	String PhoneNo;
	String Address;
	String Year;
	String Generation;
	String Degree;
	String AccountID;
}
