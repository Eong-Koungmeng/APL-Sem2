
public class Faculty
{
	String FacultyID;
	String FacultyName;
	String DeanName;
	String OfficeNo;
}
