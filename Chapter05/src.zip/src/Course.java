
public class Course
{
	String CourseID;
	String CourseName;
	String Credit;
	String Type;
}
