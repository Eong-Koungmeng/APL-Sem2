
public class TeacherDetail
{
	String TeacherID;
	String CourseID;
}
