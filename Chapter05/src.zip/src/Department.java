
public class Department
{
	String DeptID;
	String DeptName;
	String HeadName;
	String OfficeNo;
	String FacultyID;
}
