
public class DepartmentTeacherDetail
{
	String DeptID;
	String TeacherID;
}
