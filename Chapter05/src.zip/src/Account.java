
public class Account
{
	String AccountID;
	String Username;
	String Password;
	String PhoneNo;
}
