
public class DepartmentCourseDetail
{
	String DeptID;
	String CourseID;
}
